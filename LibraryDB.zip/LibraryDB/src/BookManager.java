import java.sql.*;


public class BookManager {
    public static void addBook(String title, String author, int year) {
        String query = "INSERT INTO library(book_title, book_author, book_year) VALUES(?,?,?)";
        try (Connection conn = DatabaseConnection.getConnection();
        PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1,title);
            stmt.setString(2,author);
            stmt.setInt(3,year);
            stmt.executeUpdate();
            System.out.println("Book added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void viewBooks() {
        String query = "SELECT * FROM library";
        try(Connection conn = DatabaseConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query)) {

            System.out.println("Library Books:");
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("book_id") +
                        ", Title: " + rs.getString("book_title") +
                        ", Author: " + rs.getString("book_author") +
                        ", Year: " + rs.getInt("book_year"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void searchBook(String title) {
        String query = "SELECT * FROM library WHERE book_title like ?";
        try(Connection conn = DatabaseConnection.getConnection();
            PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, "%" + title + "%");
            ResultSet rs = stmt.executeQuery();

            if (!rs.isBeforeFirst()) {
                System.out.println("No books found with that title.");
                return;
            }
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("book_id") +
                        ", Title: " + rs.getString("book_title") +
                        ", Author: " + rs.getString("book_author") +
                        ", Year: " + rs.getInt("book_year"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void deleteBook(int id) {
        String query = "DELETE FROM library where book_id = ?";
        try(Connection conn = DatabaseConnection.getConnection();
        PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            int rowsDeleted = stmt.executeUpdate();

            if(rowsDeleted > 0) {
                System.out.println("Book deleted successfully!");
            } else {
                System.out.println("Book not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
