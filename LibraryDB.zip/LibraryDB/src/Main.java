import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        while(true) {
            System.out.println("\n Library Management System");
            System.out.println("1. Add Book");
            System.out.println("2. View All Books");
            System.out.println("3. Search Book");
            System.out.println("4. Delete Book");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter author: ");
                    String author = scanner.nextLine();
                    System.out.print("Enter year: ");
                    int year = scanner.nextInt();
                    BookManager.addBook(title, author, year);
                    break;
                case 2:
                    BookManager.viewBooks();
                    break;
                case 3:
                    System.out.print("Enter book title to search: ");
                    String searchTitle = scanner.nextLine();
                    BookManager.searchBook(searchTitle);
                    break;
                case 4:
                    System.out.print("Enter book ID to delete: ");
                    int id = scanner.nextInt();
                    BookManager.deleteBook(id);
                    break;
                case 5:
                    System.out.println(" Goodbye!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("" +
                            "" +
                            "" +
                            "" +
                            "" +
                            "" +
                            "" +
                            "Invalid choice, try again.");
            }
        }
    }
}
